<?php
/**
 * Template for sidebar.
 *
 * @package Stag
 */

/**
 * This file is just a fallback in case a plugin calls for a sidebar
 * that doesn't exist. sidebar-footer-1.php is the default sidebar.
 */
get_sidebar( 'sidebar-footer-1' );
